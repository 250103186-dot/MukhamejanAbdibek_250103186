interface Pizza{
    String getDescription();
    double getCoast();
}

class PlainPizza implements Pizza{
    @Override
    public String getDescription() {
        return "Plain Dough & Sauce ";
    }

    @Override
    public double getCoast() {
        return 5;
    }
}

abstract class ToppingDecorator implements Pizza {
    protected Pizza pizza;

    public ToppingDecorator(Pizza pizza) {
        this.pizza = pizza;
    }
}

class Cheese extends ToppingDecorator{
    public Cheese(Pizza pizza){
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription()+"& Cheese ";
    }

    @Override
    public double getCoast() {
        return pizza.getCoast()+2;
    }
}

class Olives extends ToppingDecorator{
    public Olives(Pizza pizza){
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription()+"& Olives ";
    }

    @Override
    public double getCoast() {
        return pizza.getCoast()+1;
    }
}

class Pineapple extends ToppingDecorator{
    public Pineapple(Pizza pizza){
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription()+"& Pineapple ";
    }
    public double getCoast(){
        return pizza.getCoast()+1.5;
    }
}

public class Main {
    public static void main(String[] args) {
        Pizza pizza = new Pineapple(new Olives(new Cheese(new PlainPizza())));

        System.out.println(pizza.getDescription());
        System.out.println(pizza.getCoast());
    }
}